#ifndef MARCAS_H
#define MARCAS_H

int LimparVetoresMarcas(int cont);
void insereMarca();
void alteraMarca();
void pesquisarMarca();
void removeMarca();
void gravarDados_MARCAS();
void lerDados_MARCAS();
#endif
