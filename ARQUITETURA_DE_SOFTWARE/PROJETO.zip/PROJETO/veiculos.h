#ifndef VEICULOS_H
#define VEICULOS_H

int LimparVetoresVeiculos();
void insereVeiculo();
void alteraVeiculos();
void excluirVeiculo();
void pesquisarVeiculo();
void lerDados_VEICULOS();
void gravarDados_VEICULOS();
void SubMenuVeiculos(int id, int vetModulo);
#endif
