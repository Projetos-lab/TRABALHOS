#ifndef MODELOS_H
#define MODELOS_H

int LimparVetoresModelos(int cont);
int procuraIdModelos(int cont);
void imprimeIdModelos(int cont);
void alteraModelo();
void insereModelo();
void exlcuirModelo();
void pesquisarModelo();
void lerDados_MODELOS();
void gravarDados_MODELOS();

void SubMenuModelos(int id, int vetModulo);
#endif
